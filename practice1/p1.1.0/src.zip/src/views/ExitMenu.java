package views;
/*
Explanation:
- This is a view class for the ExitMenu.
- We will just use it to end the program.
 */

import java.util.Scanner;

public class ExitMenu implements AppMenu{
    @Override
    public void check(Scanner scanner) {

    }
}
